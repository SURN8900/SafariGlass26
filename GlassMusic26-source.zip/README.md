# Glass Music 26

A free, original Android music-player UI demo with an iOS-inspired translucent/dark visual style.

## What works
- Home, Search, and Library screens
- Selectable demo track list
- Mini-player play/pause state
- Daily Mix-style demo card

## Important limitations
This is a UI prototype. It does **not** stream Spotify, sign in to Spotify, access your Spotify playlists, or play audio yet. The play button changes the demo playback state only. It does not bypass subscriptions, parental controls, or app restrictions.

## Build
Open this folder as an Android project in AndroidIDE or Android Studio and build the debug APK. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35. A compatible Gradle installation and Android SDK are required.
