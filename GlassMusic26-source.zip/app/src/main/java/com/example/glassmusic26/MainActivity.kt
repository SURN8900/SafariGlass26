package com.example.glassmusic26

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var playing = false
    private var current = "Midnight City"
    private var currentArtist = "M83"
    private lateinit var playButton: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView

    private val tracks = listOf(
        "Midnight City" to "M83",
        "Blinding Lights" to "The Weeknd",
        "Starboy" to "The Weeknd",
        "A Sky Full of Stars" to "Coldplay",
        "Sweater Weather" to "The Neighbourhood",
        "505" to "Arctic Monkeys",
        "The Less I Know The Better" to "Tame Impala"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 27)
        window.navigationBarColor = Color.rgb(15, 18, 27)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))
            setBackgroundColor(Color.rgb(15, 18, 27))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("◉", 26f, Color.rgb(110, 235, 190), true))
        val heading = text("  $title", 25f, Color.WHITE, true)
        header.addView(heading)
        root.addView(header)
    }

    private fun showHome() {
        base("Good evening")
        val subtitle = text("Your sound, your space.", 14f, 0xFFADB5C5.toInt())
        subtitle.setPadding(0, dp(5), 0, dp(18)); root.addView(subtitle)

        val feature = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            background = bg(0xFF263C42.toInt(), 22)
        }
        feature.addView(text("MADE FOR YOU", 11f, 0xFFB8E9D8.toInt(), true))
        val album = TextView(this).apply {
            text = "✦"; textSize = 58f; gravity = Gravity.CENTER
            setTextColor(0xFFB8E9D8.toInt())
            background = bg(0xFF416B68.toInt(), 18)
        }
        val lp = LinearLayout.LayoutParams(-1, dp(130)); lp.topMargin = dp(12)
        feature.addView(album, lp)
        feature.addView(text("Daily Mix", 23f, Color.WHITE, true).apply { setPadding(0, dp(12), 0, 0) })
        feature.addView(text("A mix picked for your mood", 13f, 0xFFD0D8D8.toInt()))
        val listen = button("PLAY MIX") { selectTrack(tracks[0]); playing = true; updatePlayer(); }
        val listenLp = LinearLayout.LayoutParams(-1, dp(46)); listenLp.topMargin = dp(14)
        feature.addView(listen, listenLp)
        root.addView(feature)

        root.addView(text("Jump back in", 20f, Color.WHITE, true).apply { setPadding(0, dp(22), 0, dp(10)) })
        val quick = listOf("Liked Songs", "Chill Mix", "Discover Weekly", "Recently Played")
        quick.forEachIndexed { i, name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10)); background = bg(0xFF202634.toInt(), 14)
            }
            val art = TextView(this).apply {
                text = listOf("♥", "☾", "✧", "↻")[i]; textSize = 24f; gravity = Gravity.CENTER
                setTextColor(0xFFB8E9D8.toInt()); background = bg(0xFF35454B.toInt(), 10)
            }
            row.addView(art, LinearLayout.LayoutParams(dp(48), dp(48)))
            row.addView(text("  $name", 15f, Color.WHITE, true))
            row.setOnClickListener { showLibrary() }
            val rlp = LinearLayout.LayoutParams(-1, dp(68)); rlp.bottomMargin = dp(8)
            root.addView(row, rlp)
        }
        root.addView(text("Made for listening • Demo interface", 11f, 0xFF778194.toInt()).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(10))
        })
        addBottomNav("Home")
        addMiniPlayer()
    }

    private fun showLibrary() {
        base("Your Library")
        root.addView(text("Playlists and tracks", 14f, 0xFFADB5C5.toInt()).apply { setPadding(0, dp(6), 0, dp(16)) })
        tracks.forEach { track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10)); background = bg(0xFF202634.toInt(), 14)
            }
            val cover = TextView(this).apply {
                text = "♫"; textSize = 24f; gravity = Gravity.CENTER
                setTextColor(0xFFB8E9D8.toInt()); background = bg(0xFF35454B.toInt(), 10)
            }
            row.addView(cover, LinearLayout.LayoutParams(dp(48), dp(48)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            info.addView(text(track.first, 15f, Color.WHITE, true))
            info.addView(text(track.second, 12f, 0xFFADB5C5.toInt()))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("▶", 18f, 0xFFB8E9D8.toInt()))
            row.setOnClickListener { selectTrack(track); playing = true; showLibrary() }
            val lp = LinearLayout.LayoutParams(-1, dp(68)); lp.bottomMargin = dp(8)
            root.addView(row, lp)
        }
        addBottomNav("Library")
        addMiniPlayer()
    }

    private fun addBottomNav(active: String) {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(4))
        }
        listOf("Home", "Search", "Library").forEach { item ->
            val t = text((if (item == "Home") "⌂" else if (item == "Search") "⌕" else "▤") + "\n$item",
                12f, if (item == active) 0xFFB8E9D8.toInt() else 0xFF8D96A8.toInt(), item == active)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { if (item == "Library") showLibrary() else if (item == "Home") showHome() else showSearch() }
            nav.addView(t, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        root.addView(nav)
    }

    private fun showSearch() {
        base("Search")
        val field = EditText(this).apply {
            hint = "What do you want to play?"; setHintTextColor(0xFF8993A5.toInt())
            setTextColor(Color.WHITE); textSize = 15f; singleLine = true
            setPadding(dp(14), 0, dp(14), 0); background = bg(0xFF293142.toInt(), 14)
        }
        root.addView(field, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(text("Browse all", 20f, Color.WHITE, true).apply { setPadding(0, dp(22), 0, dp(12)) })
        listOf("Pop", "Chill", "Indie", "Electronic", "Focus", "Throwbacks").forEach { genre ->
            val b = button(genre) { showLibrary() }
            val lp = LinearLayout.LayoutParams(-1, dp(48)); lp.bottomMargin = dp(8); root.addView(b, lp)
        }
        addBottomNav("Search"); addMiniPlayer()
    }

    private fun button(label: String, action: () -> Unit): TextView =
        text(label, 14f, 0xFF10201C.toInt(), true).apply {
            gravity = Gravity.CENTER; background = bg(0xFFB8E9D8.toInt(), 24)
            setOnClickListener { action() }
        }

    private fun selectTrack(track: Pair<String, String>) {
        current = track.first; currentArtist = track.second
        updatePlayer()
    }

    private fun updatePlayer() {
        if (::nowTitle.isInitialized) nowTitle.text = current
        if (::nowArtist.isInitialized) nowArtist.text = currentArtist
        if (::playButton.isInitialized) playButton.text = if (playing) "Ⅱ" else "▶"
    }

    private fun addMiniPlayer() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8)); background = bg(0xFF34434A.toInt(), 15)
        }
        val art = TextView(this).apply {
            text = "♫"; textSize = 22f; gravity = Gravity.CENTER
            setTextColor(0xFFB8E9D8.toInt()); background = bg(0xFF526C6B.toInt(), 8)
        }
        panel.addView(art, LinearLayout.LayoutParams(dp(42), dp(42)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        nowTitle = text(current, 14f, Color.WHITE, true)
        nowArtist = text(currentArtist, 11f, 0xFFD0D8D8.toInt())
        info.addView(nowTitle); info.addView(nowArtist)
        panel.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        playButton = text(if (playing) "Ⅱ" else "▶", 22f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setOnClickListener { playing = !playing; updatePlayer() }
        }
        panel.addView(playButton, LinearLayout.LayoutParams(dp(42), dp(42)))
        val lp = LinearLayout.LayoutParams(-1, dp(60)); lp.topMargin = dp(8)
        root.addView(panel, lp)
    }
}
