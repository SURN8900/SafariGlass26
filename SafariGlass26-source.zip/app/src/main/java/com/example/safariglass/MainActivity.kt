package com.example.safariglass

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var webHost: FrameLayout
    private lateinit var address: EditText
    private lateinit var titleText: TextView
    private lateinit var progress: View
    private val tabs = mutableListOf<Tab>()
    private var active = 0
    private val bookmarks = linkedSetOf<String>()
    private val history = mutableListOf<String>()

    private data class Tab(val web: WebView, var url: String = "https://www.google.com")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 17, 27)
        window.navigationBarColor = Color.rgb(13, 17, 27)
        if (Build.VERSION.SDK_INT >= 31) {
            window.setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
                WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            val lp = window.attributes
            lp.blurBehindRadius = 42
            window.attributes = lp
        }
        buildUi()
        newTab("https://www.google.com")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(13, 17, 27))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(8))
            background = glass(0xDD202633.toInt(), 28)
        }
        val brandRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        titleText = TextView(this).apply {
            text = "Safari"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val spacer = View(this)
        val bookmarkBtn = smallButton("☆") { addBookmark() }
        val tabsBtn = smallButton("▢") { showTabs() }
        brandRow.addView(titleText)
        brandRow.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        brandRow.addView(bookmarkBtn)
        brandRow.addView(tabsBtn)

        address = EditText(this).apply {
            hint = "Search or enter website"
            setSingleLine(true)
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(0xFFB9C0CD.toInt())
            setPadding(dp(16), 0, dp(16), 0)
            background = glass(0xBFFFFFFF.toInt(), 24)
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigate(address.text.toString()); true
                } else false
            }
        }
        top.addView(brandRow, LinearLayout.LayoutParams(-1, dp(42)))
        top.addView(address, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        progress = View(this).apply { setBackgroundColor(0xFF8AB4FF.toInt()); visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(dp(2), dp(2)))

        webHost = FrameLayout(this)
        root.addView(webHost, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(9), dp(12), dp(12))
            background = glass(0xD9212733.toInt(), 30)
        }
        bottom.addView(navButton("‹") { goBack() }, weightParams())
        bottom.addView(navButton("›") { goForward() }, weightParams())
        bottom.addView(navButton("＋") { newTab("https://www.google.com") }, weightParams())
        bottom.addView(navButton("↻") { currentWeb()?.reload() }, weightParams())
        bottom.addView(navButton("⋯") { showMenu() }, weightParams())
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(root)
    }

    private fun newTab(url: String) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url?.toString() ?: return false
                if (target.startsWith("http://") || target.startsWith("https://")) return false
                return true
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                progress.visibility = View.VISIBLE
                if (!url.isNullOrBlank()) address.setText(url)
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                if (!url.isNullOrBlank()) {
                    address.setText(url)
                    tabs.getOrNull(active)?.url = url
                    if (history.lastOrNull() != url) history.add(url)
                }
                titleText.text = view?.title?.take(22)?.ifBlank { "Safari" } ?: "Safari"
            }
        }
        web.webChromeClient = WebChromeClient()
        val tab = Tab(web, url)
        tabs.add(tab)
        active = tabs.lastIndex
        webHost.removeAllViews()
        webHost.addView(web, FrameLayout.LayoutParams(-1, -1))
        web.loadUrl(url)
        updateTabsLabel()
    }

    private fun currentWeb(): WebView? = tabs.getOrNull(active)?.web

    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        active = index
        webHost.removeAllViews()
        webHost.addView(tabs[active].web, FrameLayout.LayoutParams(-1, -1))
        address.setText(tabs[active].web.url ?: tabs[active].url)
        titleText.text = tabs[active].web.title?.take(22) ?: "Safari"
        updateTabsLabel()
    }

    private fun navigate(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val url = when {
            input.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(input, "UTF-8")
        }
        currentWeb()?.loadUrl(url)
    }

    private fun goBack() {
        val w = currentWeb()
        if (w?.canGoBack() == true) w.goBack()
    }
    private fun goForward() {
        val w = currentWeb()
        if (w?.canGoForward() == true) w.goForward()
    }

    private fun addBookmark() {
        val url = currentWeb()?.url ?: return
        bookmarks.add(url)
        Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show()
    }

    private fun showTabs() {
        if (tabs.isEmpty()) return
        val labels = tabs.mapIndexed { i, t -> "${i + 1}. ${t.web.title?.ifBlank { t.url } ?: t.url}" }.toMutableList()
        labels.add("＋ New tab")
        AlertDialog.Builder(this)
            .setTitle("Tabs")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == tabs.size) newTab("https://www.google.com") else switchTab(which)
            }
            .setNegativeButton("Close current tab") { _, _ -> closeCurrentTab() }
            .show()
    }

    private fun closeCurrentTab() {
        if (tabs.size <= 1) {
            currentWeb()?.loadUrl("https://www.google.com")
            return
        }
        tabs.removeAt(active).web.destroy()
        active = (active - 1).coerceAtLeast(0)
        switchTab(active)
    }

    private fun showMenu() {
        val items = arrayOf("Bookmarks", "History", "Share page", "Desktop site")
        AlertDialog.Builder(this).setTitle("Safari Glass").setItems(items) { _, which ->
            when (which) {
                0 -> showList("Bookmarks", bookmarks.toList())
                1 -> showList("History", history.distinct().reversed().take(50))
                2 -> {
                    val url = currentWeb()?.url ?: return@setItems
                    startActivity(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, url)
                    }.let { Intent.createChooser(it, "Share page") })
                }
                3 -> {
                    val w = currentWeb() ?: return@setItems
                    w.settings.userAgentString = if (w.settings.userAgentString.contains("Mobile")) {
                        w.settings.userAgentString.replace(" Mobile", "")
                    } else w.settings.userAgentString + " Desktop"
                    w.reload()
                }
            }
        }.show()
    }

    private fun showList(title: String, entries: List<String>) {
        if (entries.isEmpty()) {
            Toast.makeText(this, "Nothing here yet", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this).setTitle(title).setItems(entries.toTypedArray()) { _, which ->
            navigate(entries[which])
        }.show()
    }

    private fun updateTabsLabel() {
        // Keep the tab counter compact in the top-right tab control.
    }

    private fun smallButton(label: String, action: () -> Unit) = navButton(label, action).apply {
        textSize = 19f
    }

    private fun navButton(label: String, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(0x99FFFFFF.toInt(), 24)
            setOnClickListener { action() }
        }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(46), 1f).apply {
        marginStart = dp(4); marginEnd = dp(4)
    }

    private fun glass(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(color)
            setStroke(dp(1), 0x55FFFFFF)
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onBackPressed() {
        val w = currentWeb()
        if (w?.canGoBack() == true) w.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        tabs.forEach { it.web.destroy() }
        tabs.clear()
        super.onDestroy()
    }
}
